<?php

    // Redirect

    header("location:https://store.coolenterprisesmw.com/");
    exit;

?>